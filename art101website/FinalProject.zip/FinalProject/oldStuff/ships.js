class Ships{

  constructor(rootX, rootY, c, oscale) {
    this.colorcount = 0;
    this.rx = rootX;
    this.ry = rootY;
    this.oc = c;
    this.os = oscale;
    this.gmt = 0.0;
    this.tmArr = new Array(4);
    this.tsArr = new Array(4);
    console.log(this.tmArr);
    //setupTMoves();
  }




}
