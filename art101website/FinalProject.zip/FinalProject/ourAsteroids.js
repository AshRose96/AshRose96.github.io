//Ashley Rose


var ship;
var asteroids = [];
var lasers = [];
var score=0;
var img;
var asteroid;
var ship;
var shots;
var shot;
var direction = 90;

function preload(){

img=loadImage('images/moodboard.jpg');
ship=loadImage('images/smallRocket.png');
shot=loadImage('images/shoot.png');
//asteroid=loadAnimation('floating','images/emoji001.png', 'images/emoji001.png')
}


function setup() {
  createCanvas(800, 800);
  asteroid= new Group();
  shots= new Group();
  ship = createSprite(width/2,height/2, 10,10);

  ship.addAnimation('normal','images/smallRocket.png');


  for(var j = 0; j<20; j++) {
     var newAst = createSprite(random(0, width), random(0, height));
     newAst.addAnimation('floating', 'images/ast001.png', 'images/ast005.png');
     //set a rotation speed
     newAst.rotationSpeed = -2;
     //another way to add a sprite to a group
     newAst.addToGroup(asteroid);
   }
  }


function draw() {
  background(0)
  if(s>0){
    background(img,0,0,width,height)
  }


  for(var i=0; i<allSprites.length; i++) {
    var s = allSprites[i];
    if(s.position.x<0) s.position.x = width;
    if(s.position.x>width) s.position.x = 0;
    if(s.position.y<0) s.position.y = height;
    if(s.position.y>height) s.position.y = 0;
  }



ship.attractionPoint(0.2, mouseX, mouseY);
  //since the force keeps incrementing the speed you can
  //set a limit to it with maxSpeed
  ship.maxSpeed = 5;

  //draw the sprite
  drawSprites();
  rect(50,700,120,70);
  fill(0);
  textFont('Roboto');
  textSize(50);
  text(score,90,750);
console.log(score);

}
function mouseReleased(){
  //ship.setRotation(0);
  //ship.boosting(false);
}
function mousePressed() {
   var shots = createSprite(ship.position.x, ship.position.y);
   shots.addImage(shot);
   shots.setSpeed(10+ship.getSpeed(), 5);
   shots.life = 30;
   shots.add(shots);
   asteroids.overlap(shots, asteroidHit);

}



//asteroids go here
